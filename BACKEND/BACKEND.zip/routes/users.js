const express = require('express');
const router = express.Router();
//const upload = require('../middlewares/upload');
const authController = require('../../BACKEND/controller/auth');
//const uploadController = require('../controllers/upload');

// User registration endpoint
//router.post('/register', authController.register);

// Image upload endpoint
//router.post('/upload', upload.single('image'), uploadController.upload);

module.exports = router;
